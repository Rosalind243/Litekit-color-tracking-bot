/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#define MAX_SPEED 100     // 0-100%
#define MIN_SPEED 0       // Allow full stop
#define KP 0.5           // Adjusted KP

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;

uint8_t movCmdStart          	= 0x7A;  // Package Start/Identifier
uint8_t movCmdEnd            	= 0x55;  // Package
uint8_t movCmdStopAll        	= 0x00;  // Stop all motors
uint8_t movCmdForward        	= 0x01;  // Forward
uint8_t movCmdReverse        	= 0x02;  // Reverse
uint8_t movCmdLeft			 	= 0x03;  // Left
uint8_t movCmdRight	  		 	= 0x04;  // Right
uint8_t movCmdFwdLeft	 		= 0x05;  // Diagonal Forward Left
uint8_t movCmdFwdRight 			= 0x06;  // Diagonal Forward Right
uint8_t movCmdRevLeft	 		= 0x07;  // Diagonal Reverse Left
uint8_t movCmdRevRight	 		= 0x08;  // Diagonal Reverse Right
uint8_t directionMov;

const uint16_t x_center		 	= 160;   // X-Coordinate of center
const uint16_t y_height_center 	= 150;   // height of object at center
int16_t x_difference, y_difference;
/* USER CODE BEGIN PV */
uint8_t versionReq[4]       = {0xAE, 0xC1, 0x0e, 0x00},				 // Data package to Pixy2 to request for version
		versionPack[26],											 // Array for receiving data package on version from Pixy2
		resolutionReq[]     = {0xAE, 0xC1, 0x0C, 0x01, 0x00},	     // Data package to Pixy2 to request for resolution
		resolutionPack[10],											 // Array for receiving data package on resolution from Pixy2
		brightnessReq[]     = {0xAE, 0xC1, 0x10, 0x01, 0x00},		 // Data package to Pixy2 to request for brightness
		brightnessPack[10],											 // Array for receiving data package on brightness from Pixy2
		blocksReq[]         = {0xAE, 0xC1, 0x20, 0x02, 0x01, 0x01},  // Data package to Pixy2 to request for blocks                                                                                                                        // Data package to Pixy2 to request for resolution
		blocksPack[40];									             // Array for receiving data package on blocks from Pixy2

uint16_t obj_present, x_obj, y_obj, width_obj, height_obj;  // Data on colour signature (rectangle) tracked
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART3_UART_Init(void);
/* USER CODE BEGIN PFP */
void getVersion(void);
void getResolution(void);
void setCameraBrightness(uint8_t brightness);
void getBlocks(uint8_t sigmap, uint8_t maxBlocks);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* Checksum Algorithm Function - Takes in an array of data, XOR them into a checksum and return the value */
uint8_t calculateXORchecksum(uint8_t *data, uint32_t length)
{
  uint8_t checksum = 0;  // Initialise checksum to zero
  for (uint32_t i = 0; i < length; i++)  // Runs through the XOR operation with the data
    checksum ^= data[i];

  return checksum;  // Returns the value of checksum
}

/* Movement Command Function - Set up the Movement Command Package based on specified movement and speed plus computed checksum, and transmit it out to P1 of Mobile Platform */

void move(uint8_t movement, uint8_t speed)
{
  uint8_t txByte[5];

  // Compute XOR checksum and set up Movement Command Package
  txByte[0] = movCmdStart;									    // Byte 1 - Start/Identifier (0x7A)
  txByte[1] = movement;										    // Byte 2 - Movement
  txByte[2] = speed;											// Byte 3 - Speed
  txByte[3] = movCmdEnd;										// Byte 4 - Checksum - XOR Byte 1 to 3 and 5 of package
  txByte[4] = calculateXORchecksum(txByte, sizeof(*txByte)*4);  // Byte 5 - End (0x55)
  txByte[3] = txByte[4];  										// Swap txByte[3] and txByte[4]
  txByte[4] = movCmdEnd;										//

  // Transmit out all 5 bytes of the Movement Command Package byte by byte
  for (int i = 0; i <= 4; ++i)
    HAL_UART_Transmit(&huart1, &txByte[i], 1, HAL_MAX_DELAY);
}

// getVerion() function retrieves version information about the connected Pixy2 device. This function is part of the
// Pixy2 API and helps in identifying the firmware version, hardware type, and other relevant details of the Pixy2
// module.
// Input:	void
// Output:	void
// Return:	void
void getVersion(void)
{
	if (HAL_UART_Transmit(&huart3, versionReq, sizeof(versionReq), 10) != HAL_OK)
	{
		char error_msg[50];
		sprintf(error_msg, "Error transmitting in getVersion()\n");
		HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
		return;
	}

	if (HAL_UART_Receive(&huart3, versionPack, sizeof(versionPack), 10) != HAL_OK)
	{
		char error_msg[50];
		sprintf(error_msg, "Error receiving in getVersion()\n");
		HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
		return;
	}
}

// getResolution() function retrieves the current image resolution (width and height in pixels) that the Pixy2 is
// configured to use for object detection and tracking.
// Input:	void
// Output:	void
// Return:	void
void getResolution(void)
{
	if (HAL_UART_Transmit(&huart3, resolutionReq, sizeof(resolutionReq),10) != HAL_OK)
	{
		char error_msg[50];
		sprintf(error_msg, "Error transmitting in getResolution()\n");
		HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
		return;
	}

	if (HAL_UART_Receive(&huart3, resolutionPack, sizeof(resolutionPack), 10) != HAL_OK)
	{
		char error_msg[50];
		sprintf(error_msg, "Error receiving in getResolution()\n");
		HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
		return;
	}
}

// setCameraBrightness() function adjusts the brightness level of the camera's image sensor. This setting affects how
// Pixy2 captures and processes images, which can be crucial for reliable object detection in varying lighting
// conditions.
// Input:	desired brightness setting (0 to 255)
// Output:	void
// Return:	void
void setCameraBrightness(uint8_t brightness)
{
	if (brightness <= 255 && brightness >= 0)
	{
		brightnessReq[4] = brightness; //set brightness level
	}
	else
	{
		char error_msg[50];
		sprintf(error_msg, "Brightness value is out of range 0-255 %d in setCameraBrightness()\n", brightness);
		HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
		return;
	}

	if (HAL_UART_Transmit(&huart3, brightnessReq, sizeof(brightnessReq), 10) != HAL_OK)
	{
		char error_msg[50];
		sprintf(error_msg, "Error transmitting in setCameraBrightness()\n");
		HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
		return;
	}

	char success_msg[50];
	sprintf(success_msg, "Camera brightness set to %d\n", brightness);
	HAL_UART_Transmit(&huart2, (uint8_t*)success_msg, strlen(success_msg), HAL_MAX_DELAY);

	if (HAL_UART_Receive(&huart3, brightnessPack, sizeof(brightnessPack), 10) != HAL_OK)
	{
		char error_msg[50];
		sprintf(error_msg, "Error receiving in setCameraBrightness()\n");
		HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
		return;
	}
}

// getBlocks() function is used for object detection and tracking. It retrieves the detected objects (called "blocks")
// that Pixy2 has identified based on its configured color signatures.
// Input:	void
// Output:	void
// Return:	void
void getBlocks(uint8_t sigmap, uint8_t maxBlocks)
{
	blocksReq[4] = sigmap;     // Set request on which signatures to receive data from
	blocksReq[5] = maxBlocks;  // Set request on maximum blocks to return

	if(HAL_UART_Transmit(&huart3, blocksReq, sizeof(blocksReq), 50) != HAL_OK)
	{
		char error_msg[50];
		sprintf(error_msg, "Error transmitting in getBlocks()\n");
		HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
		return;
	}

	if (HAL_UART_Receive(&huart3, blocksPack, sizeof(blocksPack), 50) != HAL_OK)
	{
		char error_msg[50];
		sprintf(error_msg, "Error receiving in getBlocks()\n");
		HAL_UART_Transmit(&huart2, (uint8_t*)error_msg, strlen(error_msg), HAL_MAX_DELAY);
		return;
	}
}


uint8_t Calculate_Speed(int16_t error) {
    uint8_t speed = (uint8_t)(fabs(error) * KP);
    return (speed < MIN_SPEED) ? MIN_SPEED : (speed > MAX_SPEED) ? MAX_SPEED : speed;
}

void Determine_Movement(int16_t x_dist, int16_t y_dist) {
	// if within parameters, stop movement
	if ((x_dist <= 10 && x_dist >= -10) && (y_dist <= 10 && y_dist >= -10)) {
        move(movCmdStopAll, 0);
        return;
    }
	// calculate horizontal and front and back speeds
    uint8_t speed_x = Calculate_Speed(x_dist); // left and right
    uint8_t speed_y = Calculate_Speed(y_dist); // forward and backward
    uint8_t avg_speed = (speed_x + speed_y) / 2; // average speed of x and y speeds

	// Horizontal or vertical dominant
	if (x_dist < -10 && (y_dist <= 10 && y_dist >= -10)){
		move(movCmdLeft, avg_speed); // only x < -10, strafe left
		directionMov = movCmdLeft;
	}
	else if (x_dist > 10 && (y_dist <= 10 && y_dist >= -10)){
		move(movCmdRight, avg_speed); // only x > 10, strafe right
		directionMov = movCmdRight;
	}
	else if ((x_dist <= 10 && x_dist >= -10) && y_dist < -10){
		move(movCmdForward, speed_y); // only y < -10, move forward
		directionMov = movCmdForward;
	}
	else if ((x_dist <= 7 && x_dist >= -7) && y_dist > 7){
		move(movCmdReverse, speed_y*2); // only y > 10, move backward
		directionMov = movCmdReverse;
	}
    else {
        // Diagonal

        if (x_dist < -10 && y_dist < -10){
        	move(movCmdFwdLeft, avg_speed); // move diagonally left + front
        	directionMov = movCmdFwdLeft;
        }
        else if (x_dist > 10 && y_dist < -10){
        	move(movCmdFwdRight, avg_speed); // move diagonally right + front
        	directionMov = movCmdFwdRight;
        }
        else if (x_dist < -10 && y_dist > 10){
        	move(movCmdRevLeft, avg_speed); // move diagonally left + back
        	directionMov = movCmdRevLeft;
        }
        else if (x_dist > 10 && y_dist > 10){
        	move(movCmdRevRight, avg_speed); // move diagonally right + back
        	directionMov = movCmdRevRight;
        }
    }
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_USART3_UART_Init();
  HAL_Delay(3000);  // Delay 3000 ms
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
	//getVersion();     // Get version info from Pixy2
	getBlocks(1, 1);  // Get blocks info from Pixy2
	//if(isObjectDetected()){
	// Extract from blocks package the info needed by the tracking algorithm
	obj_present = blocksPack[3];
	// if no objected detected the first time, change brightness until object detected
	if (obj_present == 0) {
		move(movCmdStopAll,0); // stop movement for safety
		setCameraBrightness(60); // set brightness to 150 (default)
		getBlocks(1,1); // request pixycam info
		obj_present = blocksPack[3]; // check if object is detected
		if (obj_present == 0){ // if not detected, increase brightness until object is detected
			for (int i = 30; i <= 0; i-= 10) {
				setCameraBrightness(i);       // set brightness to current level
				getBlocks(1, 1);              // get new block data
				obj_present = blocksPack[3];
				if (obj_present != 0) {       // if object is detected, break out
					break;
				}
				HAL_Delay(100); // Delay 100 ms
			}
		}
	}
	if (obj_present > 0){ // if object detected, take parameters from data received
		x_obj       = ((uint16_t)blocksPack[9] << 8) | blocksPack[8];   // get x-coordinate of object
		y_obj       = ((uint16_t)blocksPack[11] << 8) | blocksPack[10]; // get y-coordinate of object
		width_obj   = ((uint16_t)blocksPack[13] << 8) | blocksPack[12]; // get width of object
		height_obj  = ((uint16_t)blocksPack[15] << 8) | blocksPack[14]; // get height of object
		x_difference = x_obj - x_center;			 // calculate distance from centre (x-coordinate)
		y_difference = height_obj - y_height_center; // calculate difference of height from centre height
		if ((x_difference > 10 || x_difference < -10) || (y_difference > 10 || y_difference < -10)){ // if not within 10 from centre point, move litekit
			Determine_Movement(x_difference, y_difference);
		}
		else { // else if within 10 from centre point, stop movement
			move(movCmdStopAll,0);
			directionMov = movCmdStopAll;
		}
	}
	else { // if no object detected, stop movement
		move(movCmdStopAll,0);
		directionMov = movCmdStopAll;
	}

	HAL_Delay(50);  // Delay 50 ms
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);

  /*Configure GPIO pin : PA5 */
  GPIO_InitStruct.Pin = GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
